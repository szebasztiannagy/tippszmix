from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

# Chrome beállítások
chrome_options = Options()
chrome_options.add_argument("--headless")  # Ha látni szeretnéd, akkor ezt töröld
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--window-size=1920x1080")

# ChromeDriver automatikus letöltése és használata
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

driver.get("https://www.tippmixpro.hu/")
print(driver.title)  # Ellenőrzés, hogy betöltődött-e az oldal

driver.quit()
