import time
import mysql.connector
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

# 🔹 SELENIUM beállítása
options = Options()
options.add_experimental_option("detach", True)  # Böngésző nyitva marad
options.add_argument("--start-maximized")  # Maximalizált ablak

# ChromeDriver elindítása
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

# 🔹 TippmixPro oldal megnyitása
driver.get("https://www.tippmixpro.hu")

# 🔹 JavaScript kód beillesztése és futtatása a konzolban
js_script = """
const events = document.querySelectorAll('.EventItem');

let data = 'Hazai csapat;Vendég csapat;Hazai odds;Döntetlen odds;Vendég odds\\n';

events.forEach(event => {
  const homeTeam = event.querySelector('.Details__Participant--Home .Details__ParticipantName')?.innerText || 'N/A';
  const awayTeam = event.querySelector('.Details__Participant--Away .Details__ParticipantName')?.innerText || 'N/A';
  
  const oddsButtons = event.querySelectorAll('.OddsButton__Odds');
  
  const homeOdds = oddsButtons[0]?.innerText || 'N/A';
  const drawOdds = oddsButtons[1]?.innerText || 'N/A';
  const awayOdds = oddsButtons[2]?.innerText || 'N/A';

  data += `${homeTeam};${awayTeam};${homeOdds};${drawOdds};${awayOdds}\n`;
});

const blob = new Blob([data], { type: 'text/plain' });
const url = URL.createObjectURL(blob);

const a = document.createElement('a');
a.href = url;
a.download = 'matches.txt';
a.click();

URL.revokeObjectURL(url);
"""

print("JavaScript kód beillesztése és futtatása...")
driver.execute_script(js_script)  # JavaScript futtatása

# 🔹 Várunk 5 másodpercet, hogy a fájl letöltődjön
time.sleep(5)

# 🔹 Adatbázisba töltés
def create_db_connection():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="arbitrage_db"
    )
    return conn

def insert_data(home_team, away_team, home_odds, draw_odds, away_odds):
    conn = create_db_connection()
    cursor = conn.cursor()

    sql = '''
        INSERT INTO match_odds (home_team, away_team, home_odds, draw_odds, away_odds)
        VALUES (%s, %s, %s, %s, %s)
    '''
    
    values = (home_team, away_team, home_odds, draw_odds, away_odds)
    
    print(f"Beszúrandó adatok: {values}")  # Debug kiírás
    
    cursor.execute(sql, values)
    conn.commit()
    conn.close()

def load_data_from_txt(txt_file):
    with open(txt_file, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    for line in lines[1:]:  # Fejléc kihagyása
        print(f"Beolvasott sor: {line.strip()}")  

        match_data = line.strip().split(';')

        if len(match_data) == 5:
            home_team, away_team, home_odds, draw_odds, away_odds = match_data
            try:
                home_odds = float(home_odds.replace(',', '.'))  
                draw_odds = float(draw_odds.replace(',', '.'))
                away_odds = float(away_odds.replace(',', '.'))
                
                print(f"Feldolgozott adatok: {home_team} vs {away_team} | {home_odds}, {draw_odds}, {away_odds}")

                insert_data(home_team, away_team, home_odds, draw_odds, away_odds)
            except ValueError as e:
                print(f"Hiba a konvertálásnál: {e} | Sor: {line.strip()}")
        else:
            print(f"Hibás formátumú sor: {line.strip()}. Skipping line.")

    print("Adatok feldolgozása befejeződött.")

# 🔹 Adatok betöltése a letöltött TXT fájlból
txt_file = 'matches.txt'  # Győződj meg róla, hogy a fájl elérhető
load_data_from_txt(txt_file)

print("✅ Kész! Az adatok bekerültek az adatbázisba.")

# 🔹 Böngésző bezárása
driver.quit()
